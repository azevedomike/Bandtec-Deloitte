package br.com.bandtec.projetotestes3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoTestes3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
