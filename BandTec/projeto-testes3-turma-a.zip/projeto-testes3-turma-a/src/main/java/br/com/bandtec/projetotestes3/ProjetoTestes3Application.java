package br.com.bandtec.projetotestes3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjetoTestes3Application {

	public static void main(String[] args) {
		SpringApplication.run(ProjetoTestes3Application.class, args);
	}

}
