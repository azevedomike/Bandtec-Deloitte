
package com.mycompany.exercicio.figura;

import java.util.ArrayList;
import java.util.List;

public class Imagem {
        
    private List<Figura> lista;

    public Imagem() {
        this.lista = new ArrayList<Figura>();
    }
    
    
    public void adicionaFigura(Figura f){
        lista.add(f);
    }
    
    public void exibeFiguras(){
        for (Figura fig : lista) {
            System.out.println(fig);
        }
      }
       
    
        public void exibeSomaArea(){
        for (Figura fig2 : lista) {
            System.out.println(fig2.calculaArea());
        }
        }

        public void exibeFiguraAreaMaior20(){
            for (Figura figu : lista) {
                if(figu.calculaArea()>20){
                    System.out.println(figu);
                }
                
            }
        }
    public void exibeQuadrado(){
        for (Figura figura : lista) {
            if(figura instanceof Quadrado){
              System.out.println("Todas as figuras quadradas que compõem a imagem" );  
            }
         }
        
    }
    
    
    
}
