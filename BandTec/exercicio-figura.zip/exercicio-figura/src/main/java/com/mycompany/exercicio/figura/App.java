
package com.mycompany.exercicio.figura;

public class App {
    public static void main(String[] args) {
        Imagem i = new Imagem();
        Quadrado q = new Quadrado("Verde",55,33.5);
        
        i.adicionaFigura(q);
        i.exibeFiguraAreaMaior20();
        i.exibeFiguras();
        i.exibeQuadrado();
        i.exibeSomaArea();
        
        
    }
}
