
package com.mycompany.exercicio.figura;

public class Circulos extends Figura {
    private Double raio;

    public Circulos( String cor, Integer espessura,Double raio) {
        super(cor, espessura);
        this.raio = raio;
    }

    @Override
    public Double calculaArea() {
        return (Math.PI*raio*raio);
    }

    @Override
    public String toString() {
        return "Circulos{" + super.toString() + ",raio=" + raio + ",calcula=" + calculaArea() + '}';
    }
    
    
    
    
}
