
package com.mycompany.projeto.aluno.heranca;

import java.util.ArrayList;
import java.util.List;

public class Faculdade {
        private String nome;
        private Integer vagas;
        private List<Aluno> listaAlunos;
       

    public Faculdade(String nome, Integer vagas) {
        this.nome = nome;
        this.vagas = vagas;
        this.listaAlunos = new ArrayList<Aluno>();
    }
    
    public void matricularAluno(Aluno a){
          if(listaAlunos.size() < this.vagas){
            listaAlunos.add(a);
        }else{
              System.out.println("Não podemos podemos matricular Aluno.");
          }
      }
    public void exibirAlunosMatriculados(){
        if(listaAlunos.isEmpty()){
            System.out.println("A faculdade "+nome+ " não possui alunos cadastrados");
        }else{
  
                
            }
            
        }
   

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public List<Aluno> getListaAlunos() {
        return listaAlunos;
    }

    public void setListaAlunos(List<Aluno> listaAlunos) {
        this.listaAlunos = listaAlunos;
    }

    @Override
    public String toString() {
        return "Faculdade{" + "nome=" + nome + ", vagas=" + vagas + ", listaAlunos=" + listaAlunos + '}';
    }

    void matricularAluno(int i, String mike, double d, double d0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

        
        
    
}
