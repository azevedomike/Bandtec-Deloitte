
package com.mycompany.projeto.aluno.heranca;

public class AlunoPos extends Aluno {
    
    private Double notaMonografia;

    public AlunoPos( Integer ra, String nome, Double notaContinuada, Double notaSemestral,Double notaMonografia) {
        super(ra, nome, notaContinuada, notaSemestral);
        this.notaMonografia = notaMonografia;
    }

    @Override
    public Double calculaMedia() {
        return (super.getNotaContinuada() + super.getNotaSemestral() + notaMonografia) /3; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "AlunoPos{" + super.toString()+ ",notaMonografia=" + notaMonografia + '}';
    }
    
    
}
