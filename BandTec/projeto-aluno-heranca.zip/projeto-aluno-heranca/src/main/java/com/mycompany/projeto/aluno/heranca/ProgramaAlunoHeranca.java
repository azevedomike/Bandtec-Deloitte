
package com.mycompany.projeto.aluno.heranca;

public class ProgramaAlunoHeranca {
    public static void main(String[] args) {
        Aluno aluno = new Aluno(1192122,"Mike",10.0,8.0);
        System.out.println("O Aluno"+aluno.getNome()+" tem média " +aluno.calculaMedia());
        System.out.println(aluno);
        
        Aluno aluno2 = new Aluno(1192123,"Mickey",7.0,9.0);
        System.out.println("O Aluno"+aluno2.getNome()+" tem média " +aluno2.calculaMedia());
        System.out.println(aluno2);
        
        AlunoPos alunopos = new AlunoPos(1192125,"Fadinha",4.0,5.0,9.2);
        System.out.println("O Aluno"+alunopos.getNome()+" tem média " +alunopos.calculaMedia());
        System.out.println(alunopos);
        
        Faculdade faculdade = new Faculdade("Bandtec", 60);
        faculdade.matricularAluno(aluno);
        faculdade.matricularAluno(aluno2);
        faculdade.exibirAlunosMatriculados();
        
        System.out.println("O Aluno matriculado é: "+aluno.getNome());
        System.out.println("O Aluno matriculado é: "+aluno2.getNome());
        System.out.println("O Aluno matriculado é: "+alunopos.getNome());
        
          
    }
}
