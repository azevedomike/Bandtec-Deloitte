
package exercicio.aluno;

import java.util.ArrayList;
import java.util.List;

public class Cadastro {
    
    private List<Aluno> lista;

    public Cadastro() {
        this.lista = new ArrayList<Aluno>();
    }
    
    public void adicionaAluno(Aluno a){
        lista.add(a);
    }
    
    public void exibeAlunosFundamental(){
        for (Aluno a : lista) {
            if(a instanceof AlunoFundamental){
                System.out.println("Todos os alunos do ensino Fundamental: "+a);
            }
        }
    }
    
    public void exibeAlunoGraduacao(){
        for (Aluno alu : lista) {
            if(alu instanceof AlunoGraduacao){
                System.out.println("Todos os alunos do ensino graduação: "+alu);
            }
        }
    }
    
        public void exibeAlunoPos(){
        for (Aluno alup : lista) {
            if(alup instanceof AlunoPos){
                System.out.println("Todos os alunos do ensino graduação: "+alup);
            }
        }
    }
    
    
}
