
package exercicio.aluno;

public class App {
    public static void main(String[] args) {
        AlunoFundamental af = new AlunoFundamental("Maria", 20000, 5.0,6.0,7.0,5.0);
        AlunoGraduacao ag = new AlunoGraduacao ("Mike", 1192122, 8.0,10.0);
        AlunoPos ap = new AlunoPos ("Clayton", 119243405, 9.0,3.0,7.0);
        Cadastro cad = new Cadastro();
        
        cad.adicionaAluno(af);
        cad.adicionaAluno(ap);
        cad.adicionaAluno(ag);
        cad.exibeAlunoGraduacao();
        cad.exibeAlunoPos();
        cad.exibeAlunosFundamental();
    }
}
