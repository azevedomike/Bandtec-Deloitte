
package exercicio.aluno;

public abstract class Aluno {
        private String nome;
        private Integer ra;

    public Aluno(String nome, Integer ra) {
        this.nome = nome;
        this.ra = ra;
    }
        
        public abstract Double calculaMedia();

    @Override
    public String toString() {
        return "Aluno{" + "nome=" + nome + ", ra=" + ra + '}';
    }

    public String getNome() {
        return nome;
    }

    public Integer getRa() {
        return ra;
    }
        
        
}
