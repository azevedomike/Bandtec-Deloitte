
package com.mycompany.mike.azevedo.c3;

public abstract class Veterinario {
   private Integer codigo;
   private String nome;

    public Veterinario(Integer codigo, String nome) {
        this.codigo = codigo;
        this.nome = nome;
    }
   
   public abstract Double calculaSalario();

    public Integer getCodigo() {
        return codigo;
    }

    public String getNome() {
        return nome;
    }

    @Override
    public String toString() {
        return "Veterinario{" + "codigo=" + codigo + ", nome=" + nome + '}';
    }
   
   
}
