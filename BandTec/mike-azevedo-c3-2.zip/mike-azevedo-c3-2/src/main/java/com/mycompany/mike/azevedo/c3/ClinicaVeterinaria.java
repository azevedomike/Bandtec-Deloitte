
package com.mycompany.mike.azevedo.c3;

import java.util.ArrayList;
import java.util.List;

public class ClinicaVeterinaria {
    private Integer cirurgias;
    private List<Veterinario> lista;

    public ClinicaVeterinaria(Integer cirurgias) {
        this.cirurgias = cirurgias;
        this.lista = new ArrayList<Veterinario>();
    }
    
    
    public void contrataVeterinario(Veterinario vet){
        lista.add(vet);
    }

    public void exibeClinicos(){
        if(!lista.isEmpty()){
            for (Veterinario vet : lista) {
                if(vet instanceof VeterinarioClinico){
                System.out.println("Os veterinários Clinícos são: "+ vet);
                }
                }
        }else{
            System.out.println("Não há veterinários clinícos");
        }
    }
    
        public void exibeCirurgioes(){
        if(!lista.isEmpty()){
            for (Veterinario vet : lista) {
                if(vet instanceof VeterinarioCirurgiao){
                    System.out.println("Os veterinários Cirurgiões são: "+ vet);
                }
            }
        }else{
            System.out.println("Não há veterinários cirurgiões");
        }
    }
        
        
        public void exibeFolhaPagamento(){
          
            for (Veterinario veterinario : lista) {
                if(veterinario instanceof VeterinarioClinico){
                System.out.println( veterinario );
                }
            }
                        for (Veterinario veterinario : lista) {
                            if(veterinario instanceof VeterinarioCirurgiao){
                System.out.println(veterinario);
                            }
            }
        }

    @Override
    public String toString() {
        return "ClinicaVeterinaria{" + "cirurgias=" + cirurgias + ", lista=" + lista + '}';
    }
            
}