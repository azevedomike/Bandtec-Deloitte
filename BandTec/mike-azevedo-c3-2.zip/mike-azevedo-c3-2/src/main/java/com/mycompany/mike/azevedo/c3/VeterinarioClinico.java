
package com.mycompany.mike.azevedo.c3;

public class VeterinarioClinico extends Veterinario {
   
    private Integer consultas;
    private Double valorConsulta;

    public VeterinarioClinico(Integer codigo, String nome) {
        super(codigo, nome);
    }
    
    

    public VeterinarioClinico( Integer codigo, String nome, Integer consultas, Double valorConsulta) {
        super(codigo, nome);
        this.consultas = consultas;
        this.valorConsulta = valorConsulta;
    }

    @Override
    public Double calculaSalario() {
        return consultas * valorConsulta;
    }

    @Override
    public String toString() {
        return "VeterinarioClinico{" +super.toString() + ",consultas=" + consultas + ", valorConsulta=" + valorConsulta + ",calcula=" + calculaSalario()+ '}';
    }

    public Integer getConsultas() {
        return consultas;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }
    
    
    
    
    
    
}
