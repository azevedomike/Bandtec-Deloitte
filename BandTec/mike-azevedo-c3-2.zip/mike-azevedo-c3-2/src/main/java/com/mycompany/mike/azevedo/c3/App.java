package com.mycompany.mike.azevedo.c3;

public class App {
    
    public static void main(String[] args) {
        
        VeterinarioClinico vetc = new VeterinarioClinico(1193,"Mickey",3,300.0);
        VeterinarioClinico vetc2 = new VeterinarioClinico(1194,"Pateta",6,350.0);
        
        VeterinarioCirurgiao vetcr = new VeterinarioCirurgiao(1195,"Snoop",4,600.0);
        VeterinarioCirurgiao vetcr2 = new VeterinarioCirurgiao(1196,"Bob",3,650.0);
        
        ClinicaVeterinaria cv = new ClinicaVeterinaria(6);
        
        
        cv.contrataVeterinario(vetc);
        cv.contrataVeterinario(vetc2);
        cv.contrataVeterinario(vetcr);
        cv.contrataVeterinario(vetcr2);
        cv.exibeCirurgioes();
        cv.exibeClinicos();
        cv.exibeFolhaPagamento();
        
        
    }
}
