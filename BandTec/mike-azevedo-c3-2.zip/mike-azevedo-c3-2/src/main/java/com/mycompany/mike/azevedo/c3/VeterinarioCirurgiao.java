
package com.mycompany.mike.azevedo.c3;

public class VeterinarioCirurgiao extends Veterinario {
    private Integer cirurgias;
    private Double valorCirurgia;
    
    

    public VeterinarioCirurgiao( Integer codigo, String nome,Integer cirurgias, Double valorCirurgia) {
        super(codigo, nome);
        this.cirurgias = cirurgias;
        this.valorCirurgia = valorCirurgia;
    }

    @Override
    public Double calculaSalario() {
        return cirurgias * valorCirurgia;
    }

    public Integer getCirurgias() {
        return cirurgias;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    @Override
    public String toString() {
        return "VeterinarioCirurgiao{" + super.toString() + ",cirurgias=" + cirurgias + ", valorCirurgia=" + valorCirurgia + ",calcula=" + calculaSalario() + '}';
    }
    
    
    
    
    
    
}
