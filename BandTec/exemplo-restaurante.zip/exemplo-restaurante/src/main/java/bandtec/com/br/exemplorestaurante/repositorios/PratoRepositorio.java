package bandtec.com.br.exemplorestaurante.repositorios;

import bandtec.com.br.exemplorestaurante.dominio.Prato;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PratoRepositorio extends JpaRepository<Prato, Integer> {




}
