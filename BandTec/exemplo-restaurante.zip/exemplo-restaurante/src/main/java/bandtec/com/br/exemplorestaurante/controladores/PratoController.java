package bandtec.com.br.exemplorestaurante.controladores;

import bandtec.com.br.exemplorestaurante.FilaObj;
import bandtec.com.br.exemplorestaurante.Pedido;
import bandtec.com.br.exemplorestaurante.PilhaObj;
import bandtec.com.br.exemplorestaurante.dominio.Prato;
import bandtec.com.br.exemplorestaurante.repositorios.PratoRepositorio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/pratos")
public class PratoController {

    @Autowired
    private PratoRepositorio repository;


    private PilhaObj<Integer> pilha = new PilhaObj<>(20);

    private FilaObj<Pedido> fila = new FilaObj<>(20);

    private Map<UUID,Prato> pratosProntos = new HashMap<>();


    @GetMapping
    public ResponseEntity listar(){
        List<Prato> pratos = repository.findAll();


        if(pratos.isEmpty()){
            return ResponseEntity.noContent().build();
        }

        return ResponseEntity.ok(pratos);
    }

    @PostMapping
    public ResponseEntity cadastrar(@RequestBody Prato prato){
        repository.save(prato);
        pilha.push(prato.getId());
        return ResponseEntity.created(null).build();
    }

    @DeleteMapping
    public ResponseEntity desfazer(){
        if(pilha.isEmpty()){
            return ResponseEntity.ok().build();
        }
        repository.deleteById(pilha.pop());
        pilha.exibe();
        return ResponseEntity.ok().build();
    }

    @GetMapping("/preparar/{id}")
    public ResponseEntity preparar(@PathVariable Integer id){
        if(!repository.existsById(id)){
            ResponseEntity.badRequest().build();
        }
        UUID senha = UUID.randomUUID();
        Pedido pedido = new Pedido(senha ,id);
        fila.insert(pedido);
        fila.exibe();
        return ResponseEntity.accepted().header("senha", senha.toString()).build();
    }

    @GetMapping("/consultar/{senha}")
    public ResponseEntity consultar(@PathVariable UUID senha){
        Prato prato = pratosProntos.get(senha);

        if(prato == null){
            return ResponseEntity.notFound().build();
        }

        return ResponseEntity.ok(prato);
    }

    @Scheduled(fixedDelay = 10000)
    public void prepararPrato(){
        if(!fila.isEmpty()){
            Pedido pedido = fila.poll();
            Optional<Prato> optional = repository.findById(pedido.getPrato());
            if(optional.isPresent()){
                Prato prato = optional.get();
                pratosProntos.put(pedido.getSenha(),prato);
            }


        }

    }



}
