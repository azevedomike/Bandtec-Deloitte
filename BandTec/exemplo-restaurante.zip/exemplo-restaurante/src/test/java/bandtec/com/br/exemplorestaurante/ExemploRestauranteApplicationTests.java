package bandtec.com.br.exemplorestaurante;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExemploRestauranteApplicationTests {

	@Test
	void contextLoads() {
	}

}
