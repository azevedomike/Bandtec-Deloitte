
package com.mycompany.mike.azevedo.c3;

public class VeterinarioClinico {
    protected Integer codigo;
    protected String nome;
    protected Integer qtdConsulta;
    protected Double valorConsulta;

    public VeterinarioClinico(Integer codigo, String nome, Integer qtdConsulta, Double valorConsulta) {
        this.codigo = codigo;
        this.nome = nome;
        this.qtdConsulta = qtdConsulta;
        this.valorConsulta = valorConsulta;
    }
    
    
    public Double calcularSalario(){
        return qtdConsulta * valorConsulta;
    }

    @Override
    public String toString() {
        return "VeterinarioClinico{" + "codigo=" + codigo + ", nome=" + nome + ", qtdConsulta=" + qtdConsulta + ", valorConsulta=" + valorConsulta + '}';
    }
    
    

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getQtdConsulta() {
        return qtdConsulta;
    }

    public void setQtdConsulta(Integer qtdConsulta) {
        this.qtdConsulta = qtdConsulta;
    }

    public Double getValorConsulta() {
        return valorConsulta;
    }

    public void setValorConsulta(Double valorConsulta) {
        this.valorConsulta = valorConsulta;
    }
    
    
}
