
package com.mycompany.mike.azevedo.c3;

public class VeterinarioCirurgiao extends VeterinarioClinico {
    
    private Integer qtdCirurgia;
    private Double valorCirurgia;

    public VeterinarioCirurgiao(Integer codigo, String nome, Integer qtdConsulta, Double valorConsulta,Integer qtdCirurgia, Double valorCirurgia) {
        super(codigo, nome, qtdConsulta, valorConsulta);
        this.qtdCirurgia = qtdCirurgia;
        this.valorCirurgia = valorCirurgia;
    }

    @Override
    public Double calcularSalario() {
        return (this.qtdConsulta * this.valorConsulta) +(this.qtdCirurgia * this.valorCirurgia); //To change body of generated methods, choose Tools | Templates.
    }

    public Integer getQtdCirurgia() {
        return qtdCirurgia;
    }

    public void setQtdCirurgia(Integer qtdCirurgia) {
        this.qtdCirurgia = qtdCirurgia;
    }

    public Double getValorCirurgia() {
        return valorCirurgia;
    }

    public void setValorCirurgia(Double valorCirurgia) {
        this.valorCirurgia = valorCirurgia;
    }

    @Override
    public String toString() {
        return "VeterinarioCirurgiao{" + calcularSalario()+ super.toString()+ ",qtdCirurgia=" + qtdCirurgia + ", valorCirurgia=" + valorCirurgia +'}';
    }
    
    
    
    
}
