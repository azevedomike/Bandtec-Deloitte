
package com.mycompany.mike.azevedo.c3;

import java.util.ArrayList;
import java.util.List;

public class ClinicaVeterinaria {
    private String nome;
    private Integer vagas;
    private List<VeterinarioClinico> veterinarios;

    public ClinicaVeterinaria(String nome, Integer vagas) {
        this.nome = nome;
        this.vagas = vagas;
        this.veterinarios = new ArrayList<VeterinarioClinico>();
       }
    
    public void contratarVeterinario(VeterinarioClinico veterinario){
        if (veterinarios.size()<vagas){
            veterinarios.add(veterinario);
        }else{
            System.out.println("A Clínica"+ nome+ " não possuí mais vagas disponíveis.");
        }
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }

    public List<VeterinarioClinico> getVeterinarios() {
        return veterinarios;
    }

    public void setVeterinarios(List<VeterinarioClinico> veterinarios) {
        this.veterinarios = veterinarios;
    }
    
    public void exibirVeterinariosResidentes(){
        if(!veterinarios.isEmpty()){
            for (VeterinarioClinico vet : veterinarios) {
                System.out.println(vet);
                
            }
        }else{
            System.out.println("A clinica "+nome+ " não possuí veterinário");
        }
    }
}