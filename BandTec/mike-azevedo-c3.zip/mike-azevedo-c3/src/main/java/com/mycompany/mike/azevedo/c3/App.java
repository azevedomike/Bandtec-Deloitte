
package com.mycompany.mike.azevedo.c3;

public class App {
    public static void main(String[] args) {
    VeterinarioClinico vet = new VeterinarioClinico(12,"João", 2,200.0);
    VeterinarioClinico vet2 = new VeterinarioClinico(15,"Carlos", 3,250.0);
    
    VeterinarioCirurgiao vetc = new VeterinarioCirurgiao(13,"Rubens", 5,120.0,3,450.0);
    VeterinarioCirurgiao vetc2 = new VeterinarioCirurgiao(17,"André", 8,890.0,9,900.0);
   
    
        System.out.println("O salario do João é:  "+vet.calcularSalario()+ " o código"+vet.getCodigo()+" o número de consultas é "+vet.getQtdConsulta()+" e o valor das consultas é "+vet.getValorConsulta());
        System.out.println("O salário de Carlos é: "+vet2.calcularSalario()+" o código "+ vet2.getCodigo()+" o número de consultas é " + vet2.getQtdConsulta()+" e o valor das consultas é "+vet2.getValorConsulta());
        System.out.println("O salário de Rubens é "+vetc.calcularSalario()+ "o código "+ vetc.getCodigo()+ " o número de consultas é "+vetc.getQtdConsulta()+"e o valor das consultas é "+vetc.getValorConsulta()+" e a quantidade de consulta de cirurgia " +vetc.getQtdCirurgia()+ " e o valor das consultas de cirurgia "+ vetc.getValorCirurgia());
        System.out.println("O salário de André é: "+vetc2.calcularSalario()+" O código "+vetc2.getCodigo()+ " o número de consultas é "+vetc2.getQtdConsulta()+" e o valor das consultas é "+ vetc2.getValorConsulta()+ " e a quantidade de consulta de cirurgia " + vetc2.getQtdCirurgia()+ " e o valor das consultas de cirurgia " +vetc2.getQtdCirurgia());
        
        ClinicaVeterinaria cv = new ClinicaVeterinaria("Amor de Focinho",10);
        
        cv.exibirVeterinariosResidentes();
        
        cv.contratarVeterinario(vet2);
        cv.contratarVeterinario(vet);
        
        cv.exibirVeterinariosResidentes();
        
        System.out.println(cv.getNome()+" é o nome da Clinica que contém "+cv.getVagas() +" vagas");
            
        
    }
 
    
    
}
