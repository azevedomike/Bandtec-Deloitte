/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista3;

/**
 *
 * @author mikazevedo
 */
public class EntradaDeCinema {
    private Integer hora;
    private Integer sala;
    private Double valor;
    private String nome;

    public EntradaDeCinema(Integer hora, Integer sala, Double valor, String nome) {
        this.hora = hora;
        this.sala = sala;
        this.valor = valor;
        this.nome = nome;
    }

    public Integer getHora() {
        return hora;
    }

    public void setHora(Integer hora) {
        this.hora = hora;
    }

    public Integer getSala() {
        return sala;
    }

    public void setSala(Integer sala) {
        this.sala = sala;
    }

    public Double getValor() {
        return valor;
    }

    public void setValor(Double valor) {
        this.valor = valor;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public Double calculaDesconto(Boolean estudante,Integer idade ){
        if(idade < 12){
            System.out.println("O valor do seu desconto é de 50%");
            return valor = valor - valor*0.5;
        }
        else if(idade > 12 && idade <=15 && estudante == true){
            System.out.println("O valor do seu desconto é 40%");
            return valor = valor - valor*0.4;
        }
        else if(idade > 15 && idade <=20 && estudante == true){
            System.out.println("O valor do seu desconto é de 30%");
            return valor = valor - valor*0.3;
        }
        else if (idade > 20 && estudante == true){
            System.out.println("O valor do seu desconto é 20%");
            return valor = valor - valor*0.2;
        }
        return valor;
    }
    
    public void calculaDescontoHorario(Integer horario){
        if (horario < 16 ){
            System.out.println("Haverá um desconto de 10% pelo horário");
            valor = valor - valor * 0.1;
        }
    }
    
    public void exibiIngresso(){
        System.out.println(this.nome+" o seu Filme está marcado para as "+hora+ ":00 horas será na sala "
                +sala+" e ficou no valor de "+valor);
    }
}
