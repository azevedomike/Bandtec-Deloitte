/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista3;

/**
 *
 * @author mikazevedo
 */
public class TesteCinema {
    public static void main(String[] args) {
        EntradaDeCinema cinema = new EntradaDeCinema(15,7,22.5,"Mike");
        cinema.calculaDesconto(true, 15);
        cinema.calculaDescontoHorario(15);
        cinema.exibiIngresso();
        
        EntradaDeCinema cinema2 = new EntradaDeCinema(16,18,20.5,"Carlos");
        cinema2.calculaDesconto(true, 18);
        cinema2.calculaDescontoHorario(16);
        cinema2.exibiIngresso();
        
        EntradaDeCinema cinema3 = new EntradaDeCinema(12,2,31.9,"Roberta");
        cinema3.calculaDesconto(true, 22);
        cinema3.calculaDescontoHorario(12);
        cinema3.exibiIngresso();
        
        EntradaDeCinema cinema4 = new EntradaDeCinema(19,10,22.0,"Fidalgo");
        cinema4.calculaDesconto(true, 10);
        cinema4.calculaDescontoHorario(19);
        cinema4.exibiIngresso();
    }
    
}
