/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista2;

/**
 *
 * @author mikazevedo
 */
public class TesteTermometro {
    public static void main(String[] args) {
        Termometro termometro = new Termometro(23.0,25.5,18.0);
        termometro.aumentaTemperatura(27.0);
        termometro.diminuiTemperatura(17.9);
        termometro.exibeFahreinheit();
    }
}
