/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista2;

/**
 *
 * @author mikazevedo
 */
public class Termometro {
    private Double temperaturaAtual;
    private Double temperaturaMax;
    private Double temperaturaMin;

    public Termometro(Double temperaturaAtual, Double temperaturaMax, Double temperaturaMin) {
        this.temperaturaAtual = temperaturaAtual;
        this.temperaturaMax = temperaturaMax;
        this.temperaturaMin = temperaturaMin;
    }

    public Double getTemperaturaAtual() {
        return temperaturaAtual;
    }

    public void setTemperaturaAtual(Double temperaturaAtual) {
        this.temperaturaAtual = temperaturaAtual;
    }

    public Double getTemperaturaMax() {
        return temperaturaMax;
    }

    public void setTemperaturaMax(Double temperaturaMax) {
        this.temperaturaMax = temperaturaMax;
    }

    public Double getTemperaturaMin() {
        return temperaturaMin;
    }

    public void setTemperaturaMin(Double temperaturaMin) {
        this.temperaturaMin = temperaturaMin;
    }
    
    
    
    public Double aumentaTemperatura(Double aumentar){
        if(temperaturaAtual < temperaturaMax){
                return temperaturaAtual = aumentar;
        }
        return temperaturaAtual;
    }
        public Double diminuiTemperatura(Double diminuir){
        if(temperaturaAtual > temperaturaMin){
                return temperaturaAtual = diminuir;
        }
        return temperaturaAtual;
    }
    public void exibeFahreinheit(){
        Double temperaturaFahreinheit;
        temperaturaFahreinheit = temperaturaAtual * 1.8 + 32;
        System.out.println("A Temperatura em Fahreinheit é: " +temperaturaFahreinheit);
    }
    
}
