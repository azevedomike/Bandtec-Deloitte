/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author mikazevedo
 */
public class Empregado {
    private String cargo;
    private Double salario;

    public Empregado(String cargo, Double salario) {
        this.cargo = cargo;
        this.salario = salario;
    }

    public String getCargo() {
        return cargo;
    }

    public void setCargo(String cargo) {
        this.cargo = cargo;
    }

    public Double getSalario() {
        return salario;
    }

    public void setSalario(Double salario) {
        this.salario = salario;
    }
    
    public double reajustarSalario(Double reajuste){
        return salario = salario + (salario*reajuste);
        
    }
    public void exibiDados(){
        System.out.println("Cargo: "+cargo);
        System.out.println("Salario: "+salario);
    }
}
