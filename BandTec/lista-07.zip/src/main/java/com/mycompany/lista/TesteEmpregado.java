/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.lista;

/**
 *
 * @author mikazevedo
 */
public class TesteEmpregado {
    public static void main(String[] args) {
        Empregado empregado = new Empregado("Analista de Sistemas", 5.400);
        empregado.exibiDados();
        System.out.println("O salário com reajuste é: "+empregado.reajustarSalario(0.15));
        
        Empregado empregado2 = new Empregado("Analista Jr.", 5.000);
        empregado2.exibiDados();
        System.out.println("O salário com reajuste é: "+empregado2.reajustarSalario(0.10));
    }
}
