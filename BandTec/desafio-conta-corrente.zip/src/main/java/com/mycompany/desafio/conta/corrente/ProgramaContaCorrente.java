package com.mycompany.desafio.conta.corrente;

public class ProgramaContaCorrente {
    public static void main(String[] args) {
        ContaCorrente conta = new ContaCorrente("Mike", 5000.00);
        conta.sacar(100.00, 02, 03, 2020);
        conta.depositar(300.00, 03,04 ,2020);
        conta.depositar(1000.00, 10, 04, 2020);
        conta.sacar(399.00, 13, 04, 2020);
        conta.exibirExtrato();
        
    }
}
