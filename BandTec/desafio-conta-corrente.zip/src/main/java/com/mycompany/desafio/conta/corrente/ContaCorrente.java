package com.mycompany.desafio.conta.corrente;

import java.util.ArrayList;
import java.util.List;

public class ContaCorrente {
   private String titular;
   private Double saldo;
   private  List<Historico> lista;
   
   
   
    public ContaCorrente(String titular, Double saldo) {
        this.titular = titular;
        this.saldo = saldo;
        this.lista = new ArrayList<>();
    }

    public String getTitular() {
        return titular;
    }

    public void setTitular(String titular) {
        this.titular = titular;
    }

    public Double getSaldo() {
        return saldo;
    }

    public void setSaldo(Double saldo) {
        this.saldo = saldo;
    }
   
   public void sacar(Double saque, Integer diaSaque, Integer mesSaque, Integer anoSaque){
       Historico hist = new Historico();
       this.saldo = saldo - saque;
       hist.setDia(diaSaque);
       hist.setMes(mesSaque);
       hist.setAno(anoSaque);
       hist.setOperacao("Saque");
       hist.setValor(saque);
       lista.add(hist);
   }
   
   public void depositar(Double deposito, Integer diaDeposito, Integer mesDeposito, Integer anoDeposito){
       Historico hist = new Historico();
       this.saldo = saldo + deposito;
       hist.setDia(diaDeposito);
       hist.setMes(mesDeposito);
       hist.setAno(anoDeposito);
       hist.setOperacao("Depósito");
       hist.setValor(deposito);
       lista.add(hist);
   }
 
  
   public void exibirExtrato(){
       
       for (Historico h: lista){
       System.out.println("---------------------------------");
       System.out.println("O valor da transação é: "+h.getValor());
       System.out.println(" No dia: "+h.getDia()+"/"+h.getMes()+"/"+h.getAno());
       System.out.println(" E essa foi uma operação de: "+h.getOperacao());
       System.out.println("---------------------------------");
       }
       
   }
}
