
package com.mycompany.projeto.professor.heranca;

public class Coordenador extends Professor {
    private Integer qtdHorasCoord;
    private Double valorHoraCoord;
    private String curso;

    public Coordenador( String nome, Integer codigo, Integer horas, Double valorHora,Integer qtdHorasCoord, Double valorHoraCoord, String curso) {
        super(nome, codigo, horas, valorHora);
        this.qtdHorasCoord = qtdHorasCoord;
        this.valorHoraCoord = valorHoraCoord;
        this.curso = curso;
    }

    @Override
    public Double calcularSalario() {
        return super.calcularSalario() + qtdHorasCoord * valorHoraCoord * 4.5 ; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return "Coordenador{"+super.toString() + ",qtdHorasCoord=" + qtdHorasCoord + ", valorHoraCoord=" + valorHoraCoord + ", curso=" + curso + '}';
    }

    
    
    
}
