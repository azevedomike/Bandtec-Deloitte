
package com.mycompany.projeto.professor.heranca;

public class ClasseApp {
    public static void main(String[] args) {
        Professor prof = new Professor("Célia",1192122,12,120.0);
        Coordenador cord = new Coordenador("Yoshi",1192123,15,190.0,13,150.0,"CCO");
        Professor prof2 = new Professor("Marise",1192125,14,140.0);
        Coordenador cord2 = new Coordenador("Brandão",1192126,11,150.0,13,150.0,"PI");
        Professor prof3 = new Professor("Gerson",1192127,20,120.0);
        Coordenador cord3 = new Coordenador("Vera",1192121,30,200.0,13,150.0,"SOCIO");
        
        System.out.println(cord);
        System.out.println(prof);
        System.out.println(prof.calcularSalario());
        System.out.println(cord.calcularSalario());
        
        Escola escola = new Escola("Bandtec",50);
        
        escola.contratarProfessor(prof);
        escola.contratarProfessor(prof2);
        escola.contratarProfessor(prof3);;
        escola.exibirProfessores();
            
    }
}
