
package com.mycompany.projeto.professor.heranca;

import java.util.ArrayList;
import java.util.List;

public class Escola {
    private String nome;
    private Integer vagas;
    private List<Professor> professores;

    public Escola(String nome, Integer vagas) {
        this.nome = nome;
        this.vagas = vagas;
        this.professores = new ArrayList<Professor>();
    }

    public void contratarProfessor(Professor P){
        if(professores.size()< vagas){
            professores.add(P);
        }else{
            System.out.println("Não foi possível adicionar a lista por falta de vagas.");
        }
    }
    
    public void exibirProfessores(){
        System.out.println("Os dados do professor "+professores.toString());
 {
        System.out.println("Os dados do professor "+professores.toString());
        }
       
              
    }
    
    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getVagas() {
        return vagas;
    }

    public void setVagas(Integer vagas) {
        this.vagas = vagas;
    }
    
    
    
}
