package br.com.bandtec.projetoapireativa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProjetoApiReativaApplicationTests {

	@Test
	void contextLoads() {
	}

}
